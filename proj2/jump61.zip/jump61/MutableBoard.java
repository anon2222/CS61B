package jump61;

import static jump61.Side.*;
import static jump61.Square.square;
import java.util.*;

/** A Jump61 board state that may be modified.
 *  @author Bo Liu
 */
class MutableBoard extends Board {

    /** An N x N board in initial configuration. */
    MutableBoard(int N) {
        _size = N;
        initialize();
    }


   /** Initializing the board. */
   private void initialize() {
        _mutableBoard = new Square[_size][_size];
        for (int i = 0; i < size(); i += 1) {
            for (int j = 0; j < size(); j += 1) {
                _mutableBoard[i][j] = Square.INITIAL;
            }
        }
    }

    /** A board whose initial contents are copied from BOARD0, but whose
     *  undo history is clear. */
    MutableBoard(Board board0) {
        copy(board0);
        _undoHistory = new Stack<MutableBoard>();
    }

    @Override
    void clear(int N) {
        initialize();
        _undoHistory = new Stack<MutableBoard>();
        announce();
    }

    @Override
    void copy(Board board) {
        _mutableBoard = new Square[board.size()][board.size()];
        for (int i = 0; i < size(); i += 1) {
            for (int j = 0; j < size(); j += 1) {
                _mutableBoard[i][j] = board.get(i + 1, j + 1);
            }
        }

    }

    /** Copy the contents of BOARD into me, without modifying my undo
     *  history.  Assumes BOARD and I have the same size. */
    private void internalCopy(MutableBoard board) {
        for (int i = 0; i < board.size(); i += 1) {
            for (int j = 0; j < board.size(); j += 1) {
                _mutableBoard[i][j] = board.get(i + 1, j + 1);
            }
        }

    }

    @Override
    int size() {
        return _size;
    }

    @Override
    Square get(int n) {
        return _mutableBoard[row(n) - 1][col(n) - 1];
    }

    @Override
    int numOfSide(Side side) {
        int count = 0;
        for (int i = 0; i < size(); i += 1) {
            for (int j = 0; j < size(); j += 1) {
                if (_mutableBoard[i][j].getSide() == side) {
                    count += 1;
                }
            }
        }
        return count;
    }

    @Override
    int numPieces() {
        int sum = 0;
        for (int i = 1; i<= size(); i+= 1) {
            for (int j = 1; j <= size(); j += 1) {
                sum += _mutableBoard[i][j].getSpots();
            }
        }
        return sum;
    }

    @Override
    void addSpot(Side player, int r, int c) {
        markUndo();
        System.out.println(_undoHistory);
        add(player, r, c);
        announce();
    }

    /** Addspot. */
    private void add(Side player, int r, int c) {
        int sp = get(r, c).getSpots();
        _mutableBoard[r - 1][c - 1] = square(player, sp + 1);
        if (overfull(player, r, c)) {
            overfull(player, sqNum(r, c));
        }
    }

    /** Checks if current square is overfull. */
    private boolean overfull(Side player, int r, int c) {
        return _mutableBoard[r - 1][c - 1].getSpots() > neighbors(r, c);
    }

    /** A square calls on this method when overfull. */
    private void overfull(Side player, int n) {
        _mutableBoard[row(n) - 1][col(n) - 1] = square(player, 1);
        if (exists(sqNum(row(n), col(n) - 1))) {
            addSpot(player, row(n), col(n) - 1);
        }
        if (exists(sqNum(row(n), col(n) + 1))) {
            addSpot(player, row(n), col(n) + 1);
        }
        if (exists(sqNum(row(n) - 1, col(n)))) {
            addSpot(player, row(n) - 1, col(n));
        }
        if (exists(sqNum(row(n) + 1, col(n)))) {
            addSpot(player, row(n) + 1, col(n));
        }
    }

    @Override
    void addSpot(Side player, int n) {
        addSpot(player, row(n), col(n));
        announce();
    }

    @Override
    void set(int r, int c, int num, Side player) {
        internalSet(sqNum(r, c), square(player, num));
    }

    @Override
    void set(int n, int num, Side player) {
        internalSet(n, square(player, num));
        announce();
    }

    @Override
    void undo() {
        if (_undoHistory != null) {
            MutableBoard temp = _undoHistory.pop();
            internalCopy(temp);
        }
    }

    /** Record the beginning of a move in the undo history. */
    private void markUndo() {
        MutableBoard cp = new MutableBoard(this);
        System.out.println(cp);
        _undoHistory.push(cp);
    }

    /** Set the contents of the square with index IND to SQ. Update counts
     *  of numbers of squares of each color.  */
    private void internalSet(int ind, Square sq) {
        _mutableBoard[row(ind) - 1][col(ind) - 1] = sq;
    }

    /** Notify all Observers of a change. */
    private void announce() {
        setChanged();
        notifyObservers();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof MutableBoard)) {
            return obj.equals(this);
        } else {
            // REPLACE WITH SOLUTION
            return false;
        }
    }

    @Override
    public int hashCode() {
        // REPLACE WITH SOLUTION.  RETURN A NUMBER THAT IS THE SAME FOR BOARDS
        // WITH IDENTICAL CONTENTS (IT NEED NOT BE DIFFERENT IF THE BOARDS
        // DIFFER.)  THE CURRENT STATEMENT WORKS, BUT IS NOT PARTICULARLY
        // EFFICIENT.
        return 0;
    }

    private Stack<MutableBoard> _undoHistory = new Stack<MutableBoard>();
    private Square [][] _mutableBoard;
    private int _size;

}
